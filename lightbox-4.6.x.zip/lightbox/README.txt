LIGHTBOX MODULE Version 0.6
-----------------

Drupal Lightbox Module:
By: Mark Ashmead

Licensed under the Creative Commons Attribution 2.5 License - http://creativecommons.org/licenses/by/2.5/
- Any variant of this module should bear my name as credit.

This module enables the use of lightbox which places images above your current page, not within. This frees you from the constraints of the layout, particularly column widths..

---------------------------------------------------------------------------------------------------------

Original Lightbox:
By: Lokesh Dhakar - http://www.huddletogether.com

Licensed under the Creative Commons Attribution 2.5 License - http://creativecommons.org/licenses/by/2.5/
- Any variant of Lokesh Dhakar's original source should bear his name as credit.


Installation
------------
1. Copy lightbox folder to modules directory
2. At admin/modules enable the module
3. Add rel="lightbox" attribute to any link tag to activate the lightbox. For example:

<a href="images/image-1.jpg" rel="lightbox" title="my caption">image #1</a>

Optional: Use the title attribute if you want to show a caption.


Information
-------------

This module will include the lightbox CSS and JS file in your Drupal Installation without the need to edit the theme.
